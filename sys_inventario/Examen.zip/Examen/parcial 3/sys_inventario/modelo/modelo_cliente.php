<!-- Este lo copie de inventario_model y cambie las variables para el nuevo cliente -->
<?php
require_once('bd/conexion.php');

class modelo_cliente {

    private $con;

    public function __construct(){
        $this->con = Conexion::conectar();
    }

    public function Nuevo_cliente($id,$nombre,$correo,$dui,$direccion,$telefono){
       
        $sql = "INSERT INTO clientes(id,nombre,correo,dui,direccion,telefono)
                VALUES('$id','$nombre','$correo','$dui','$direccion','$telefono')";

        return $this->con->query($sql);
    }

    public function get(){
        return $this->con->query("SELECT * FROM clientes");
    }
}