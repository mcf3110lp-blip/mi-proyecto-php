<!-- Este lo copie de inventario.controller y cambie para lo del nuevo cliente -->
<?php
require_once(__DIR__ . '/../modelo/modelo_cliente.php');
require_once(__DIR__ . '/BaseController.php');

class inventario_cliente extends BaseController {

    private $model;

    public function __construct(){
        $this->model = new modelo_cliente();
    }

    public function guardarcliente(){
        $this->model->Nuevo_cliente(
            $_POST['id'],
            $_POST['nombre'],
            $_POST['correo'],
            $_POST['dui'],
            $_POST['direccion'],
            $_POST['telefono']
        );

        header("Location: index.php?m=listacliente");
    }

    public function listacliente(){
        $datos = $this->model->get();
        $this->view('inventario/cliente', ['datos'=>$datos]);
    }

    public function cliente(){
        $datos = $this->model->get();
        $this->view('inventario/lista_cliente', ['datos'=>$datos]);
    }
}