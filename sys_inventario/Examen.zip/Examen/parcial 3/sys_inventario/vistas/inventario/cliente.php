
<div class="container mt-4"> <!-- ESTE FORMULARIO LO COPIE DE FORM.PHP Y LO MODIFIQUE PARA EL EL FORMULARIO DEL CLIENTE 
    PARA QUE PUEDA  AGREGAR LOS CAMPOS DEL NUEVO -->

<div class="d-flex justify-content-between mb-4">
    <h3 class="title">Registro de cliente</h3>

    <div>
        <a href="index.php?m=cliente" class="btn btn-primary">Reporte Cliente</a>
        <a href="index.php?m=logout" class="btn btn-danger">Cerrar sesión</a>
    </div>
</div>

<div class="row">

<!-- FORMULARIO -->
    <div class="col-md-8">

    <div class="card p-4 shadow-soft">

    <form method="POST" action="index.php?m=guardarcliente">

    <div class="row">
        <div class="col-md-6 mb-3">
    <label>id</label>
    <input name="id" class="form-control" required>
    </div>

    <div class="col-md-6 mb-3">
    <label>nombre</label>
    <input name="nombre" class="form-control" required>
    </div> 

    <div class="row">
    <div class="col-md-6 mb-3">
    <label>correo</label>
    <input name="correo" class="form-control" required>
    </div> 
     
    <div class="col-md-6 mb-3">
    <label>dui</label>
    <input name="dui" class="form-control" required>
    </div>

    <div class="col-md-6 mb-3">
    <label>direccion</label>
    <input name="direccion" class="form-control" required>
    </div>

    <div class="col-md-6 mb-3">
    <label>telefono</label>
    <input name="telefono" class="form-control" required>
    </div>


</div>

<button class="btn btn-success w-100 mt-3">Guardar</button>

</form>

</div>

</div>