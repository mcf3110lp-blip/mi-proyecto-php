<h4 class="title mb-3">Inventario cliente</h4>

<div class="d-flex justify-content-between mb-3"> <!-- ESTE LO COPIE DE LISTA.PHP Y LE PUSE LOS CAMPOS PARA CLIENTE -->
    <div>
        <a href="index.php?m=guardarcliente" class="btn btn-primary">Nuevo_cliente</a>
        <a href="index.php?m=dashboard" class="btn btn-success">Regresar</a>
    </div>

    <a href="index.php?m=logout" class="btn btn-danger">Salir</a>
</div>
<div class="card shadow-soft p-3">

<table class="table table-hover align-middle">
<thead>
<tr>
<th>id</th>
<th>nombre</th>
<th>correo</th>
<th>dui</th>
<th>direccion</th>
<th>telefono</th>
</tr>
</thead>

<tbody>
<?php while($r=mysqli_fetch_assoc($datos)){ ?>
<tr>
<td><?= $r['id'] ?></td>
<td><?= $r['nombre'] ?></td>
<td><?= $r['correo'] ?></td>
<td><?= $r['dui'] ?></td>
<td><?= $r['direccion'] ?></td>
<td><?= $r['telefono'] ?></td>
</tr>
<?php } ?>
</tbody>

</table>

</div>