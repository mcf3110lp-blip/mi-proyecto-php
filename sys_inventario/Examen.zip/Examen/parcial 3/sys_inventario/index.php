<?php
session_start();

require_once('controlador/usuario_controller.php');
require_once('controlador/inventario_controller.php');
require_once('controlador/inventario_cliente.php');

$u = new usuario_controller();
$i = new inventario_controller();
$c = new inventario_cliente();

$metodo = $_REQUEST['m'] ?? 'index';

switch($metodo){

    case 'login': $u->login(); break;
    case 'logout': $u->logout(); break;
    case 'dashboard': $u->dashboard(); break;

    case 'guardar': $i->guardar(); break;
    case 'listar': $i->listar(); break;
    case 'reporte': $i->reporte(); break;

    case 'guardarcliente': $c->guardarcliente(); break;
    case 'listacliente': $c->listacliente(); break;
    case 'Nuevo_cliente': $c->Nuevo_cliente(); break;
    case 'cliente': $c->cliente(); break;

    default: $u->index(); break;
}